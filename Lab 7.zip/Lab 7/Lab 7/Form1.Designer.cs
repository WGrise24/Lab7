﻿namespace Lab_7
{
	partial class interestForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.finValue = new System.Windows.Forms.TextBox();
			this.intValue = new System.Windows.Forms.TextBox();
			this.yearValue = new System.Windows.Forms.TextBox();
			this.calcBtn = new System.Windows.Forms.Button();
			this.fValue = new System.Windows.Forms.Label();
			this.iValue = new System.Windows.Forms.Label();
			this.yearsLbl = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// finValue
			// 
			this.finValue.Location = new System.Drawing.Point(126, 36);
			this.finValue.Name = "finValue";
			this.finValue.Size = new System.Drawing.Size(100, 20);
			this.finValue.TabIndex = 0;
			// 
			// intValue
			// 
			this.intValue.Location = new System.Drawing.Point(126, 62);
			this.intValue.Name = "intValue";
			this.intValue.Size = new System.Drawing.Size(100, 20);
			this.intValue.TabIndex = 1;
			// 
			// yearValue
			// 
			this.yearValue.Location = new System.Drawing.Point(126, 88);
			this.yearValue.Name = "yearValue";
			this.yearValue.Size = new System.Drawing.Size(100, 20);
			this.yearValue.TabIndex = 2;
			// 
			// calcBtn
			// 
			this.calcBtn.Location = new System.Drawing.Point(68, 121);
			this.calcBtn.Name = "calcBtn";
			this.calcBtn.Size = new System.Drawing.Size(75, 23);
			this.calcBtn.TabIndex = 3;
			this.calcBtn.Text = "Calculate";
			this.calcBtn.UseVisualStyleBackColor = true;
			this.calcBtn.Click += new System.EventHandler(this.calcBtn_Click);
			// 
			// fValue
			// 
			this.fValue.AutoSize = true;
			this.fValue.Location = new System.Drawing.Point(31, 39);
			this.fValue.Name = "fValue";
			this.fValue.Size = new System.Drawing.Size(70, 13);
			this.fValue.TabIndex = 4;
			this.fValue.Text = "Future Value ";
			// 
			// iValue
			// 
			this.iValue.AutoSize = true;
			this.iValue.Location = new System.Drawing.Point(31, 65);
			this.iValue.Name = "iValue";
			this.iValue.Size = new System.Drawing.Size(68, 13);
			this.iValue.TabIndex = 5;
			this.iValue.Text = "Interest Rate";
			// 
			// yearsLbl
			// 
			this.yearsLbl.AutoSize = true;
			this.yearsLbl.Location = new System.Drawing.Point(31, 91);
			this.yearsLbl.Name = "yearsLbl";
			this.yearsLbl.Size = new System.Drawing.Size(86, 13);
			this.yearsLbl.TabIndex = 6;
			this.yearsLbl.Tag = "label3";
			this.yearsLbl.Text = "Number of Years";
			// 
			// interestForm
			// 
			this.AcceptButton = this.calcBtn;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(261, 174);
			this.Controls.Add(this.yearsLbl);
			this.Controls.Add(this.iValue);
			this.Controls.Add(this.fValue);
			this.Controls.Add(this.calcBtn);
			this.Controls.Add(this.yearValue);
			this.Controls.Add(this.intValue);
			this.Controls.Add(this.finValue);
			this.Name = "interestForm";
			this.Text = "Lab 7";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox finValue;
		private System.Windows.Forms.TextBox intValue;
		private System.Windows.Forms.TextBox yearValue;
		private System.Windows.Forms.Button calcBtn;
		private System.Windows.Forms.Label fValue;
		private System.Windows.Forms.Label iValue;
		private System.Windows.Forms.Label yearsLbl;
	}
}

