﻿//A8977
//Lab 7
//CIS-199-01
//November 11, 2018 @ 11:59pm
//Program for using methods to determine investment amount needed to reach future goals
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_7
{
	public partial class interestForm : Form
	{
		public interestForm()
		{
			InitializeComponent();
		}
		private void calcBtn_Click(object sender, EventArgs e)
			//Preconditions: Financial Goal >=0
			//Interest Rate >=0
			//Years >=0
		{
			double F = 0;//The amount you want to have in the future
			double r = 0;//The interest rate
			int n = 0;//The number of years
			if(double.TryParse(finValue.Text,out F) && (F >= 0))//TryParse for determining the validty of the future amount wanted
			{
				if (double.TryParse(intValue.Text,out r)&& (r >=0) && (r<=1))//TryParse for the interest rate
				{
					if(int.TryParse(yearValue.Text,out n) && (n>=0))//TryParse for the number of years
 					{
						MessageBox.Show($"The amount you need to invest to meet your future goal is {CalcPresentValue(n,F,r):c}");//Displays the results from the other method
					}
					else
					{
						MessageBox.Show("Enter a valid number of years");//Else statement for years
					}
				}
				else
				{
					MessageBox.Show("Enter a valid interest rate between 0 and 1");//Else statement for interest rates 
				}
			}
			else
			{
				MessageBox.Show("Please enter a valid positive future value");//Else statement for the future value
			}
				
			
		}
		//PostConditions: The values from this must be usable in the method for calculate the proper value for present investment
		public static object CalcPresentValue(int n, double F,double r)//Method for determining the amount you need to invest
		//Precondition: The output of CalcPresentValue must be greater than or equal to 0
		{
			
			return F / Math.Pow((1 + r), n);//Math formula for calculating amount you need to invest

		}
		//PostCondition: THe output must be input back into the main method in a MessageBox for the user
}	}
